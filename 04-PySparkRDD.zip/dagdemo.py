lines = sc.textFile("/FileStore/tables/war_and_peace.txt",4)
nonNullLines = lines.filter(lambda line: len(line)>0) 
words = nonNullLines.flatMap(lambda line: line.split())

upperWords = words.map(lambda word: word.upper())
pairedOnes = upperWords.map(lambda uw: (uw, 1))
wordCounts = pairedOnes.reduceByKey(lambda prev, next: prev + next)

wordCounts.count()



