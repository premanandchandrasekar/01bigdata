# Make you create your first Kafka topic from kafka directory with the command below
# $ bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic kafka-topic1

# Run this PySpark application with the following arguments
# pyspark --jars spark-streaming-kafka-0-8-assembly_2.11-2.4.8.jar --master local[*]

# Import StreamingContext which is the main entry point for all streaming functionality.

from pyspark.streaming import StreamingContext

# Import Kafka Utils from the library jar file specified

from pyspark.streaming.kafka import KafkaUtils

# Create a SparkContext with two execution threads, and StreamingContext with batch interval of 1 second.

# sc = SparkContext("local[2]", "StreamingKafka1")
ssc = StreamingContext(sc, 1)

# Using this context, we can create a DStream that gets streaming data from the Kafka topic specified
# kafkaStream = KafkaUtils.createStream(streamingContext, [ZK quorum], [consumer group id], [per-topic number of Kafka partitions to consume])

kafkaStream = KafkaUtils.createStream(ssc, 'localhost:2181', 'kafka-streaming-group', {'kafka-topic1':1})

# This lines DStream represents the stream of data that will be received from the data server.

lines = kafkaStream.map(lambda x: (x[0],x[1]))
lines.pprint()

ssc.start()
ssc.awaitTermination()

# We can terminate it by interrupting the kernel (sending Control+C)
ssc.stop()
sc.stop()
