# Make you create your first Kafka topic from kafka directory with the command below
# bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic kafka-kv-topic --property print.key=true --property key.separator=,

# This prgram reads a given text file and publishes the the lines of the file one by one to the given topic.
# Use pip install kafka-python if not done already.
# Create a Kafka topic using kafka topics create command and specify the name in the code below.
# Make sure the text file specified in the code is present in the present working directory

from kafka import KafkaProducer
from kafka.errors import KafkaError

# Create a producer object
producer = KafkaProducer(bootstrap_servers=['localhost:9092'])

count = 0
# Read the lines from the given text file and in a loop publish each line to the specified topic
file1 = open('warandpeace50.txt', 'r')
for line in file1:
    count += 1
    producer.send('kafka-python2', str(count)+','+line

print("Done")
# Closing files
file1.close()
