# Create a DataFrame from an RDD through reflection method
# 

from pyspark.sql import Row

# Create an RDD from the structured text file

clines = sc.textFile("/user/hadoop/sparkdata/customers.tsv")
type(clines)
for line in clines.take(5):
    print(line)

# Transform this RDD of text lines to an RDD of "Row"s with each Row having the 5 fields of the text input lines.

cfields = clines.map(lambda l: l.split("\t"))
for line in cfields.take(5):
    print(line)


customers = cfields.map(lambda p: Row(cid=int(p[0]),cname=p[1],ccity=p[2],cstate=p[3],czip=p[4]))
for line in customers.take(5):
    print(line)

# Infer the schema, and register the DataFrame as a table (temp view).

customerDF = spark.createDataFrame(customers)

customerDF.printSchema()

customerDF.select("cname").show()

customerDF.select(customerDF['cname'], customerDF['ccity']).show()

customerDF.filter(customerDF['cstate'] == 'CA').show()

customerDF.groupBy("cstate").count().show()


# Create the temp view to be able to run SQL queries on the DataFrame

customerDF.createOrReplaceTempView("customers")

cStateCount50 = spark.sql("SELECT cstate, count(*) as sttcount FROM customers GROUP BY cstate HAVING sttcount>=50")

cStateCount50.show()

cStateCount50.printSchema()

type(cStateCount50)

