# The following three lines are required if you are running PySpark using Jupyter notebook with Python3 as kernel 
import pyspark

from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("PySpark SQL Functions - Examples").getOrCreate()

# Create DataFrame from data source - csv file
customerDF = spark.read.load("customers.txt", format="csv", sep="\t", inferSchema="true", header="true")

customerDF.count()

# Different types of operations on DataFrames

customerDF.printSchema()

customerDF.select("customer_name","customer_city").show()

customerDF.select(customerDF.customer_name,customerDF.customer_city).show(n=5)

customerDF.select(customerDF['customer_name'], customerDF['customer_city']).show(5)

customerDF.where(customerDF['customer_state'] == 'CA').show()

df2=customerDF.where(customerDF['customer_state'] == 'CA')

type(df2)

df2.show(5)

customerDF.groupBy("customer_state").count().show()

# Aggregatons like sum, min, max, avg can be done as shown later below

customerDF.groupBy("customer_state").count().orderBy("customer_state").show()

from pyspark.sql.functions import *

customerDF.groupBy("customer_state").count().orderBy(col("customer_state").desc()).show()

customerDF.groupBy("customer_state").count().sort("customer_state").show()

customerDF.groupBy("customer_state").count().sort(col("customer_state").desc()).show()

productDF = spark.read.load("products.json", format="json")

# Alternatively the following syntax is also allowed

# productDF = spark.read.json("products.json")

# We can now run set of the DataFrame operations

productDF.printSchema()

productDF.select("product_name").show()

productDF.select("product_name").show(truncate=False)

productDF.select("product_name").show(5,False)

productDF.select(productDF['product_name'], productDF['product_category'], productDF['product_price']).show(5,False)

productDF.filter(productDF['product_price'] > 200.00).show()

productDF.groupBy("product_category").count().show()

productDF.groupBy("product_category").max("product_price").show()

productDF.groupBy("product_category").avg("product_price").show()

productDF.groupBy("product_category").agg(avg("product_price").alias("average_price"))

productDF.groupBy("product_category").agg(round(avg("product_price"),2).alias("average_price")).show()

productDF.groupBy("product_category").agg( sum("product_price").alias("sum_price"), avg("product_price").alias("avg_price"), max("product_price").alias("max_price"), min("product_price").alias("min_price") ).show(truncate=False)


# The follwoing import statement is not required as we have used from pyspark.sql.functions import * above
# from pyspark.sql.functions import col, lit

# withColumn
## cast
prodDF2=productDF.withColumn('customer_id',col('customer_id').cast("Integer"))
prodDF2.printSchema()

# withColumn
## add a new column with constant
prodDF3=prodDF2.withColumn('discount',lit(10.0))
prodDF3.printSchema()
prodDF3.show(5)

# withColumn
## add a new column calculated with existing columns
# df.withColumn("CopiedColumn",col("salary")* -1).show()
prodDF4=prodDF3.withColumn('discounted_price',col('product_price')*(100-col('discount'))/100)
prodDF4.printSchema()
prodDF4.show(5)

# withColumnRenamed
prodDF5=prodDF4.withColumnRenamed('customer_id','prodcust_id')
prodDF5.printSchema()
prodDF5.show(5)

# Using alias to rename a column
prodDF5a = prodDF4.select(col('category_id'),col('customer_id').alias('prodcust_id'),col('product_category'),col('product_name'),col('product_price'),col('product_quantity'),col('salestxn_id'),col('discount'),col('discounted_price'))

prodDF5a.printSchema()
prodDF5a.show(5)

# join
newDF=customerDF.join(prodDF5,customerDF.customer_id==prodDF5.prodcust_id,'outer')
newDF.printSchema()

newDF.select('customer_id','customer_name','customer_city','prodcust_id','product_name','product_price','product_quantity').where(newDF.customer_state=='IL').show()

# df.na.fill on columns with a string type data
newDF2=newDF.na.fill(value='Not Available',subset=['product_name','product_category'])
newDF2.printSchema()
newDF2.select('customer_id','customer_name','customer_city','product_category','prodcust_id','product_name','product_price','product_quantity').where(newDF.customer_state=='IL').show()

# df.na.fill on columns with an integer type data
newDF3=newDF2.na.fill(value=0,subset=['prodcust_id','category_id'])

newDF3.printSchema()

newDF3.select('customer_id','customer_name','customer_city','category_id','product_category','prodcust_id',              'product_name','product_price','product_quantity').where(newDF.customer_state=='IL').show()

collist=newDF.columns
type(collist)

collist

for c in collist:
    print(c)

len(collist)

for c in newDF.columns:
    print(c)

len(newDF.columns)

colnum=1;
for mycol in collist:
    print(colnum,mycol)
    colnum+=1
print('Done')

for i in range(len(collist)):
    print(i,collist[i])

print('Done')

