#!/bin/bash

rm -r /tmp/spooltest 2>/dev/null
mkdir /tmp/spooltest

i=$2
while IFS= read line
do
    # echo $line into a file
    i=$(expr $i + 1)
    echo "$line" > /tmp/spooltest/file_$i
    sleep 1s
done <"$1"

