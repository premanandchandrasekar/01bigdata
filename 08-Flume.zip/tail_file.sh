#!/bin/bash

rm -r /tmp/logtest/ 2>/dev/null
mkdir /tmp/logtest/

while IFS= read line
do
    # echo $line into a file
    echo "$line" >> /tmp/logtest/testfile.log
    sleep 1s
done <"$1"

