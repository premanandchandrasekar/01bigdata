#!/bin/bash

while IFS= read line
do
    # display $line or do something with $line
    echo "$line"
    sleep 1s
done <"$1"

